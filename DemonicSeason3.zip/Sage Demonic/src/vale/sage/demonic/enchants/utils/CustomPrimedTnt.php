<?php

declare(strict_types = 1);

namespace vale\sage\demonic\enchants\utils;

use pocketmine\entity\object\PrimedTNT;

class CustomPrimedTnt extends PrimedTNT {

}
<?php

namespace vale\sage\demonic\addons\types\regions\exception;

use Exception;

class AreaException extends Exception {

}
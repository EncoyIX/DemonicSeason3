<?php

namespace SOFe\AwaitStd;

use SOFe\AwaitStd\_ab913d46\SOFe\AwaitGenerator\Await as Shaded;

class_alias(Shaded::class, __NAMESPACE__ . "\\Await");
